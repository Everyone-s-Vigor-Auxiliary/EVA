package com.example.eva;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class DetailActivity extends AppCompatActivity {

    private TextView txtResult;
    private TextView txtTime;
    private RoomModel roomModel;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        getSupportActionBar().setTitle("Detail Room");

        txtResult = findViewById(R.id.txtResult);
        txtTime = findViewById(R.id.txtTime);

        roomModel = getIntent().getParcelableExtra("data_user");

        setData();

    }

        private void setData(){
            txtTime.setText(roomModel.getTime());
            txtResult.setText(roomModel.getResult());

        }
}