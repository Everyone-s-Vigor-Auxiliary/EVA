package com.example.eva;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import com.example.eva.Tools.VerticalSpaceItemDecoration;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private static final int VERTICAL_ITEM_SPACE = 48;
    private ArrayList<RoomModel> list = new ArrayList<>();
    private RecyclerView rvRoom;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rvRoom = findViewById(R.id.rvRoom);
        list.addAll(DataRoom.getListData());
        showRV();

    }
    private void showRV(){
        rvRoom.setLayoutManager(new LinearLayoutManager(this));
        RoomAdapter recyclerAdapter = new RoomAdapter(this, list);
        rvRoom.setAdapter(recyclerAdapter);
        rvRoom.addItemDecoration(new VerticalSpaceItemDecoration(VERTICAL_ITEM_SPACE));
    }
}