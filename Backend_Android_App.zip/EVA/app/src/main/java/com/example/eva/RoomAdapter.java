package com.example.eva;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class RoomAdapter extends RecyclerView.Adapter<RoomAdapter.RoomViewHolder>{
    private Context context;
    private List<RoomModel> list;

    public RoomAdapter(Context context, List<RoomModel> list){
        this.context = context;
        this.list = list;
    }

    public class RoomViewHolder extends RecyclerView.ViewHolder {

        TextView txtRoomId;
        Button btn;

        public RoomViewHolder(@NonNull View itemView) {
            super(itemView);
            txtRoomId = itemView.findViewById(R.id.txtRoomid);
            btn = itemView.findViewById(R.id.btnRoom);
        }
    }

    @NonNull
    @Override
    public RoomViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.row_room, parent, false);
        return new RoomViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RoomViewHolder holder, int position) {

            holder.txtRoomId.setText(String.valueOf(position + 1));
            holder.btn.setOnClickListener(v -> {
            Intent intent = new Intent(context, DetailActivity.class);
            intent.putExtra("data_user", list.get(position));
            context.startActivity(intent);

        });
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

}
