package com.example.eva;

import android.os.Parcel;
import android.os.Parcelable;

public class RoomModel implements Parcelable {

    String id;
    String time;
    String result;

    protected RoomModel(Parcel in) {
        id = in.readString();
        time = in.readString();
        result = in.readString();
    }

    public static final Creator<RoomModel> CREATOR = new Creator<RoomModel>() {
        @Override
        public RoomModel createFromParcel(Parcel in) {
            return new RoomModel(in);
        }

        @Override
        public RoomModel[] newArray(int size) {
            return new RoomModel[size];
        }
    };

    public RoomModel(String id, String time, String result){
        this.id = id;
        this.time = time;
        this.result = result;
    }

    public RoomModel() {

    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(id);
        dest.writeString(time);
        dest.writeString(result);
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
