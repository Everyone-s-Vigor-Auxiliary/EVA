package com.example.eva.API;

import com.example.eva.BuildConfig;
import com.example.eva.RoomModel;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Headers;
import retrofit2.http.Path;

public interface APIRoom {

    @GET("users/{username}")
    @Headers("Authorization: token "+ BuildConfig.TOKEN)
    Call<RoomModel> getDetailUser(
            @Path("username") String username
    );
}
