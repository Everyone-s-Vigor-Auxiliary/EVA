package com.example.eva;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import com.example.eva.Tools.VerticalSpaceItemDecoration;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private static final int VERTICAL_ITEM_SPACE = 48;
    private ArrayList<RoomModel> list = new ArrayList<>();
    private RecyclerView rvRoom;
    private List<Integer> mImages;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        getSupportActionBar().setIcon(R.drawable.logoeva);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rvRoom = findViewById(R.id.rvRoom);
        mImages = new ArrayList<>();
        mImages.add(R.drawable.ic_baseline_room);
        list.addAll(DataRoom.getListData());


        showRV();

    }
    private void showRV(){
        GridLayoutManager gridLayoutManager =  new GridLayoutManager(this, 2, GridLayoutManager.VERTICAL, false);
        //rvRoom.setLayoutManager(new LinearLayoutManager(this));
        rvRoom.setLayoutManager(gridLayoutManager);
        RoomAdapter recyclerAdapter = new RoomAdapter(this, list, mImages);
        rvRoom.setAdapter(recyclerAdapter);
        rvRoom.addItemDecoration(new VerticalSpaceItemDecoration(VERTICAL_ITEM_SPACE));
    }
}