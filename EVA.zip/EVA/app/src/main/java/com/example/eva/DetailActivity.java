package com.example.eva;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class DetailActivity extends AppCompatActivity {

    private TextView txtResult;
    private TextView txtTime;
    private RoomModel roomModel;
    private Button btn;
    private String phonenumber = "089658600097";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        getSupportActionBar().setTitle("Detail Room");

        txtResult = findViewById(R.id.txtResult);
        txtTime = findViewById(R.id.txtTime);
    btn=findViewById(R.id.btnSecurity);
        roomModel = getIntent().getParcelableExtra("data_user");
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(isTelephonyEnabled()){
                    Uri number = Uri.parse("tel:"+phonenumber);
                    Intent dial = new Intent(Intent.ACTION_DIAL);
                    dial.setData(number);
                    startActivity(dial);
                }
            }
        });
        setData();

    }

    private boolean isTelephonyEnabled(){
        TelephonyManager tm = (TelephonyManager)getSystemService(TELEPHONY_SERVICE);
        return tm != null && tm.getSimState()==TelephonyManager.SIM_STATE_READY;
    }

        private void setData(){
            txtTime.setText(roomModel.getTime());
            txtResult.setText(roomModel.getResult());

        }
}