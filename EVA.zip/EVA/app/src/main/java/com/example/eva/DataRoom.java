package com.example.eva;

import java.util.ArrayList;

public class  DataRoom {
    private static final String[] time = {
            "17:05",
            "21:10",
            "10:12",
            "12:25",
            "01:51"
    };

    private static String[] result = {
            "31",
            "51",
            "72",
            "79",
            "70"
    };

    static ArrayList<RoomModel> getListData() {
        ArrayList<RoomModel> list = new ArrayList<>();
        for (int position = 0; position < time.length; position++) {
            RoomModel roomModel = new RoomModel();
            roomModel.setTime(time[position]);
            roomModel.setResult(result[position]);
            list.add(roomModel);
        }
        return list;
    }
}
