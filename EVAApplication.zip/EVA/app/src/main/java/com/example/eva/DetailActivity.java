package com.example.eva;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class DetailActivity extends AppCompatActivity {

    private TextView txtResult;
    private TextView txtTime;
    private RoomModel roomModel;
    private Button btn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        getSupportActionBar().setTitle("Detail Room");

        txtResult = findViewById(R.id.txtResult);
        txtTime = findViewById(R.id.txtTime);
    btn=findViewById(R.id.btnSecurity);
        roomModel = getIntent().getParcelableExtra("data_user");
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent callIntent = new Intent(Intent.ACTION_CALL);
                callIntent.setData(Uri.parse("tel:089658600097"));
                startActivity(callIntent);
            }
        });
        setData();

    }

        private void setData(){
            txtTime.setText(roomModel.getTime());
            txtResult.setText(roomModel.getResult());

        }
}