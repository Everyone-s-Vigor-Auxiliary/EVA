package com.example.eva;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class RoomAdapter extends RecyclerView.Adapter<RoomAdapter.RoomViewHolder>{
    private Context context;
    private List<RoomModel> list;
    private List<Integer> images;



    public RoomAdapter(Context context, List<RoomModel> list, List<Integer> images){
        this.context = context;
        this.images = images;
        this.list = list;
    }

    public class RoomViewHolder extends RecyclerView.ViewHolder {

        TextView txtRoomId;
        Button btn;
        ImageView mImageView;

        public RoomViewHolder(@NonNull View itemView) {
            super(itemView);
            txtRoomId = itemView.findViewById(R.id.txtRoomid);
            mImageView = itemView.findViewById(R.id.imageView);
            btn = itemView.findViewById(R.id.btnRoom);
        }
    }

    @NonNull
    @Override
    public RoomViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.grid_item, parent, false);
        return new RoomViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RoomViewHolder holder, int position) {

            holder.txtRoomId.setText("Room "+String.valueOf(position + 1));
            holder.btn.setOnClickListener(v -> {
            Intent intent = new Intent(context, DetailActivity.class);
            intent.putExtra("data_user", list.get(position));
            context.startActivity(intent);

        });
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

}
